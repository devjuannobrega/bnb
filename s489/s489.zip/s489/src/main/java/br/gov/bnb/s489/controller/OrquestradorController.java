package br.gov.bnb.s489.controller;

import br.gov.bnb.s489.model.dto.ReceiverDTO;
import br.gov.bnb.s489.model.dto.ResponseDTO;
import br.gov.bnb.s489.service.OrquestradorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/br/gov/bnb/s489")
@RequiredArgsConstructor
public class OrquestradorController {

    private final OrquestradorService orquestradorService;

    @PostMapping("/orquestrador")
    public ResponseEntity<ResponseDTO> receber(@RequestBody ReceiverDTO request) {
        ResponseDTO response = orquestradorService.processar(request);
        return ResponseEntity.ok(response);
    }
}
