package br.gov.bnb.s489;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrquestradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
